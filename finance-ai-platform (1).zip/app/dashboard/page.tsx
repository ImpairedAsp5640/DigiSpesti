import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, DollarSign, LineChart, PiggyBank, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border p-4 space-y-6">
        <div className="py-2">
          <Link href="/" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </Link>
        </div>

        <nav className="space-y-1 flex-1">
          {[
            { name: "Dashboard", href: "/dashboard", active: true },
            { name: "Savings", href: "/savings" },
            { name: "Investments", href: "/investments" },
            { name: "Budget AI", href: "/budget-ai" },
            { name: "Financial Goals", href: "/goals" },
            { name: "Market Insights", href: "/insights" },
            { name: "For Business", href: "/business" },
            { name: "Success Stories", href: "/stories" },
            { name: "Education", href: "/learn" },
            { name: "Support", href: "/support" },
          ].map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`block px-3 py-2 rounded-md transition-colors ${
                item.active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="pt-4 border-t border-border">
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/settings">Settings</Link>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border">
          <button className="md:hidden">
            <span className="sr-only">Open menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          <div className="md:hidden flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Log in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/signup">Sign up</Link>
            </Button>
          </div>
        </header>

        {/* Dashboard content */}
        <div className="flex-1 p-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-primary via-wealth-gold to-accent bg-clip-text text-transparent">
                  Financial Dashboard
                </h1>
                <p className="text-muted-foreground">Overview of your financial health and progress</p>
              </div>
              <div className="mt-4 md:mt-0 flex gap-2">
                <Button variant="outline" size="sm">
                  Export
                </Button>
                <Button size="sm">Ask Budget AI</Button>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card className="border-wealth-gold/20 bg-gradient-to-br from-background to-wealth-gold/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Total Balance</CardTitle>
                  <DollarSign className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-wealth-gold">$24,563.00</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-accent">+$2,100</span> from last month
                  </p>
                </CardContent>
              </Card>

              <Card className="border-wealth-gold/20 bg-gradient-to-br from-background to-wealth-gold/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Savings Rate</CardTitle>
                  <PiggyBank className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-wealth-gold">24%</div>
                  <p className="text-xs text-muted-foreground">
                    <span className="text-accent">+3%</span> from last month
                  </p>
                </CardContent>
              </Card>

              <Card className="border-wealth-gold/20 bg-gradient-to-br from-background to-wealth-gold/5">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <CardTitle className="text-sm font-medium">Investment Growth</CardTitle>
                  <TrendingUp className="h-4 w-4 text-primary" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-wealth-gold">+8.2%</div>
                  <p className="text-xs text-muted-foreground">YTD performance</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Spending Overview</CardTitle>
                  <CardDescription>Your spending patterns for the last 30 days</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px] flex items-center justify-center bg-muted/40 rounded-md">
                    <LineChart className="h-8 w-8 text-muted-foreground" />
                    <span className="ml-2 text-muted-foreground">Spending chart visualization</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>AI Insights</CardTitle>
                  <CardDescription>Personalized financial recommendations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-gradient-to-r from-wealth-navy/5 to-wealth-gold/5 border border-wealth-gold/10 rounded-md">
                    <p className="font-medium text-sm">Reduce subscription costs</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      You could save $42/month by optimizing your streaming subscriptions.
                    </p>
                    <Button variant="link" size="sm" className="px-0 mt-1">
                      View details <ArrowRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>

                  <div className="p-3 bg-gradient-to-r from-wealth-navy/5 to-wealth-gold/5 border border-wealth-gold/10 rounded-md">
                    <p className="font-medium text-sm">Savings opportunity</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Increasing your 401(k) contribution by 2% could save $840 in taxes this year.
                    </p>
                    <Button variant="link" size="sm" className="px-0 mt-1">
                      View details <ArrowRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>

                  <div className="p-3 bg-gradient-to-r from-wealth-navy/5 to-wealth-gold/5 border border-wealth-gold/10 rounded-md">
                    <p className="font-medium text-sm">Budget alert</p>
                    <p className="text-sm text-muted-foreground mt-1">You're 15% over your dining budget this month.</p>
                    <Button variant="link" size="sm" className="px-0 mt-1">
                      View details <ArrowRight className="ml-1 h-3 w-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

