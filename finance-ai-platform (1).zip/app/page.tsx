import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, ExternalLink, Play, Share2 } from "lucide-react"

export default function Home() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border p-4 space-y-6">
        <div className="py-2">
          <Link href="/" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </Link>
        </div>

        <nav className="space-y-1 flex-1">
          {[
            { name: "Dashboard", href: "/dashboard" },
            { name: "Savings", href: "/savings" },
            { name: "Investments", href: "/investments" },
            { name: "Budget AI", href: "/budget-ai" },
            { name: "Financial Goals", href: "/goals" },
            { name: "Market Insights", href: "/insights" },
            { name: "For Business", href: "/business" },
            { name: "Success Stories", href: "/stories" },
            { name: "Education", href: "/learn" },
            { name: "Support", href: "/support" },
          ].map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className="block px-3 py-2 rounded-md hover:bg-muted transition-colors"
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="pt-4 border-t border-border">
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/settings">Settings</Link>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border">
          <button className="md:hidden">
            <span className="sr-only">Open menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          <div className="md:hidden flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Log in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/signup">Sign up</Link>
            </Button>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 overflow-auto">
          <div className="max-w-4xl mx-auto px-4 py-12 md:py-24">
            <div className="text-center mb-8">
              <div className="text-sm text-muted-foreground mb-2">March 20, 2025 • Product</div>
              <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-8 bg-gradient-to-r from-primary via-wealth-gold to-accent bg-clip-text text-transparent">
                Introducing Budget AI
              </h1>

              <div className="flex flex-wrap justify-center gap-4">
                <Button className="gap-2">
                  Try Budget AI <ArrowRight className="h-4 w-4" />
                </Button>
                <Button variant="outline" className="gap-2">
                  Download mobile app <ExternalLink className="h-4 w-4" />
                </Button>
                <Button variant="outline" className="gap-2">
                  Learn about Budget AI <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex items-center justify-center gap-4 my-8 text-sm">
              <button className="flex items-center gap-2">
                <Play className="h-4 w-4" /> Listen to article
              </button>
              <span className="text-muted-foreground">4:53</span>
              <button className="flex items-center gap-2">
                <Share2 className="h-4 w-4" /> Share
              </button>
            </div>

            <div className="prose prose-lg max-w-none">
              <p className="text-xl leading-relaxed">
                We've developed an AI-powered financial assistant called Budget AI that interacts in a conversational
                way. The dialogue format makes it possible for Budget AI to analyze your spending patterns, suggest
                personalized savings strategies, help you set realistic financial goals, and provide actionable insights
                to improve your financial health.
              </p>

              <div className="bg-gradient-to-r from-wealth-navy/10 via-wealth-gold/10 to-accent/10 border border-wealth-gold/20 rounded-xl p-6 my-8 flex items-center justify-between">
                <p className="font-medium">Ask Budget AI about your finances</p>
                <Button
                  variant="secondary"
                  size="sm"
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Try now
                </Button>
              </div>

              <h2 className="text-2xl font-bold mt-12 mb-4">Smart Financial Planning</h2>
              <p>
                Budget AI analyzes your income, expenses, and financial goals to create a personalized budget that
                adapts to your lifestyle. It identifies spending patterns and suggests areas where you can save money
                without sacrificing your quality of life.
              </p>

              <h2 className="text-2xl font-bold mt-12 mb-4">Automated Savings</h2>
              <p>
                Set up automated savings rules based on your spending habits and income. Budget AI can automatically
                transfer small amounts to your savings account when it detects you have extra funds available, making
                saving effortless.
              </p>

              <h2 className="text-2xl font-bold mt-12 mb-4">Investment Recommendations</h2>
              <p>
                Receive personalized investment recommendations based on your risk tolerance, financial goals, and
                market conditions. Budget AI helps you build a diversified portfolio aligned with your long-term
                objectives.
              </p>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

