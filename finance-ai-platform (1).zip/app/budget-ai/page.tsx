import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Send } from "lucide-react"
import Link from "next/link"

export default function BudgetAI() {
  return (
    <div className="flex min-h-screen">
      {/* Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-border p-4 space-y-6">
        <div className="py-2">
          <Link href="/" className="flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </Link>
        </div>

        <nav className="space-y-1 flex-1">
          {[
            { name: "Dashboard", href: "/dashboard" },
            { name: "Savings", href: "/savings" },
            { name: "Investments", href: "/investments" },
            { name: "Budget AI", href: "/budget-ai", active: true },
            { name: "Financial Goals", href: "/goals" },
            { name: "Market Insights", href: "/insights" },
            { name: "For Business", href: "/business" },
            { name: "Success Stories", href: "/stories" },
            { name: "Education", href: "/learn" },
            { name: "Support", href: "/support" },
          ].map((item) => (
            <Link
              key={item.name}
              href={item.href}
              className={`block px-3 py-2 rounded-md transition-colors ${
                item.active ? "bg-primary/10 text-primary font-medium" : "hover:bg-muted"
              }`}
            >
              {item.name}
            </Link>
          ))}
        </nav>

        <div className="pt-4 border-t border-border">
          <Button variant="ghost" className="w-full justify-start" asChild>
            <Link href="/settings">Settings</Link>
          </Button>
        </div>
      </aside>

      {/* Main content */}
      <main className="flex-1 flex flex-col">
        {/* Header */}
        <header className="flex items-center justify-between p-4 border-b border-border">
          <button className="md:hidden">
            <span className="sr-only">Open menu</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-6 w-6"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>

          <div className="md:hidden flex items-center space-x-2">
            <div className="h-8 w-8 rounded-full bg-emerald-500 flex items-center justify-center">
              <span className="text-white font-bold">$</span>
            </div>
            <span className="font-semibold text-xl">WealthWise</span>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Log in</Link>
            </Button>
            <Button size="sm" asChild>
              <Link href="/signup">Sign up</Link>
            </Button>
          </div>
        </header>

        {/* Chat interface */}
        <div className="flex-1 flex flex-col max-w-4xl mx-auto w-full p-4">
          <div className="text-center my-8">
            <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-primary via-wealth-gold to-accent bg-clip-text text-transparent">
              Budget AI
            </h1>
            <p className="text-muted-foreground">Your personal financial assistant powered by AI</p>
          </div>

          <div className="flex-1 space-y-6 overflow-auto py-4">
            <Card className="p-4 max-w-[80%]">
              <p className="text-sm font-medium mb-1">Budget AI</p>
              <p>
                Hello! I'm your personal finance assistant. I can help you with budgeting, saving strategies, investment
                advice, and more. What would you like to know about your finances today?
              </p>
            </Card>

            <Card className="p-4 max-w-[80%] ml-auto bg-gradient-to-r from-primary to-wealth-gold text-primary-foreground border-wealth-gold/50">
              <p className="text-sm font-medium mb-1">You</p>
              <p>I want to save for a down payment on a house. Can you help me create a savings plan?</p>
            </Card>

            <Card className="p-4 max-w-[80%]">
              <p className="text-sm font-medium mb-1">Budget AI</p>
              <p>
                That's a great goal! To help you create a savings plan for a house down payment, I'll need some
                information:
              </p>
              <ol className="list-decimal pl-5 mt-2 space-y-1">
                <li>What's your target down payment amount?</li>
                <li>What's your timeline for buying a house?</li>
                <li>What's your current monthly income and expenses?</li>
                <li>Do you have any existing savings?</li>
              </ol>
              <p className="mt-2">
                Once I have this information, I can create a personalized savings plan that fits your budget and
                timeline.
              </p>
            </Card>
          </div>

          <div className="border-t pt-4">
            <div className="flex gap-2">
              <Input placeholder="Ask about your finances..." className="flex-1" />
              <Button size="icon">
                <Send className="h-4 w-4" />
                <span className="sr-only">Send</span>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Budget AI can make mistakes. Consider checking important information.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}

